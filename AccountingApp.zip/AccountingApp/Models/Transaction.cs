public class Transaction
{
    public int TransactionID { get; set; }
    public int CustomerID { get; set; }
    public decimal Amount { get; set; }
    public DateTime Date { get; set; }
    
    public Customer Customer { get; set; } = new Customer(); // حل الخطأ
}

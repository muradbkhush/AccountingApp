public class Customer
{
    public int CustomerID { get; set; }
    public string Name { get; set; } = string.Empty; // حل الخطأ
    public string Email { get; set; } = string.Empty; // حل الخطأ
    public string Phone { get; set; } = string.Empty; // حل الخطأ
}

﻿using System.Windows;
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        // تحميل CustomersView عند بدء التشغيل
        MainFrame.Navigate(new CustomersView());
    }
}
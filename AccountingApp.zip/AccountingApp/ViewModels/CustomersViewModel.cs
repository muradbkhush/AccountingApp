using System.Windows.Input;
using System.Collections.ObjectModel;

public class CustomersViewModel
{
    public ObservableCollection<Customer> Customers { get; set; } = new ObservableCollection<Customer>();
    public ICommand AddCustomerCommand { get; }

    public CustomersViewModel()
    {
        AddCustomerCommand = new RelayCommand(AddCustomer);
    }

    private void AddCustomer()
    {
        Customers.Add(new Customer { Name = "عميل جديد", Phone = "0000000000" });
    }
}
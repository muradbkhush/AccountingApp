using System.Windows;

namespace AccountingApp.Views
{
    public partial class TransactionsView : Window
    {
        public TransactionsView()
        {
            InitializeComponent();
        }

        private void AddTransaction_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("تمت إضافة الحركة المالية بنجاح!");
        }
    }
}

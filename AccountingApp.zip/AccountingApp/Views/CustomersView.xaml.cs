using System.Windows;

namespace AccountingApp.Views
{
    public partial class CustomersView : Window
    {
        public CustomersView()
        {
            InitializeComponent();
        }

        private void AddCustomer_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("تمت إضافة العميل بنجاح!");
        }
    }
}
